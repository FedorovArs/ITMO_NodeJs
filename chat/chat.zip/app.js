var express = require('express');
var app = express();
var server = require('http').createServer(app);
var io = require('socket.io').listen(server);

server.listen(9000);
app.get('/', function (req, res) {
    res.sendFile(__dirname + '/index.html');
});

let users = [];
let connections = [];

io.sockets.on('connection', function (socket) {
    console.log("Соединение успешно установлено");
    connections.push(socket);

    socket.on('disconnect', function (data) {
        connections.splice(connections.indexOf(socket), 1);
        console.log("Disconnect выполнен успешно");
    });

    socket.on('send mess', function (data) {
        io.sockets.emit('add mess', {mess: data.mess, name: data.name})
    })
});


// let rooms = [];
//
// socket.on('create room', function (data) {
//
//     let roomId = uuid.v4();
//     socket.join(roomId);
//     let roomSocket = io.sockets.connected[socketId];
//     rooms.push({name: data.roomName, id: roomId, socket: roomSocket});
//     io.sockets.emit('create room info', {mess: data.mess, name: data.name})
//
//
// });